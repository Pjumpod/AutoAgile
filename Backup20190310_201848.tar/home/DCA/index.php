<!DOCTYPE html>
<HTML><HEAD>

<style>
input{width: 50%; text-align:center;}
div.relative2 {width: 70%; padding 10px; border: 5px solid #316ED6; background-color: #648CD1; color: #31D8EB; margin: auto; text-align: center;}
div.relative1{width: 70%; padding 10px; border: 5px solid #316ED6; background-color: #648CD1; color: #31D8EB; margin: auto; text-align: center;}
.hover_img a { position:relative; }
.hover_img a span { position:absolute; display:none;   left:50%; z-index:99;
  -webkit-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  transform: translateX(-50%); }
.hover_img a:hover span { display:block; }
</style>
<title>picture search</title>
</HEAD>
<BODY>
<br/>
<br/>
    <?php
$ScriptName = basename(__FILE__);
if (isset($_POST['submittestid'])) {
	$rNumber = rand(1,10000);
	$site = $_POST['SITE'];
	$testid = $_POST['TestID'];
	$testid = trim($testid);
	$filename = "$testid$rNumber.xml";
	$cmd = "wget -O /tmp/$filename $site$testid";
	$output = shell_exec($cmd);
	#$cmd = "cat /tmp/$testid.xml";
	#$output = shell_exec($cmd);
	$splitString = explode("/", $site);
	$testdev = $splitString[2];
	#$serialnumber = (xmlstarlet el 273985933.xml | grep SerialNumber | grep DataSheet | grep -v Custom)
	#$cmd = "xmlstarlet el /tmp/$testid.xml | grep SerialNumber | grep DataSheet | grep -v Custom";
	#$snNode = shell_exec($cmd);
	$cmd = "cat /tmp/$filename | tail -n +2 | xmlstarlet sel -t -v '*/DataSheet/SerialNumber' ";
	$sn = shell_exec($cmd);
	#echo "<br/>$sn";
	#$cmd = "xmlstarlet el /tmp/$testid.xml | grep Start | grep -v \/TestData";
	#$StartTimeNode = shell_exec($cmd);
	$cmd = "cat /tmp/$filename | tail -n +2 | xmlstarlet sel -t -v '*/StartTime' ";
	$StartTime = shell_exec($cmd);
	$TimeArray = explode(".", $StartTime);
	$StartTime = $TimeArray[0];
	#echo "<br/> Start Time = $StartTime";
	#$cmd = "xmlstarlet el /tmp/$testid.xml | grep End | grep -v \/TestData";
	#$EndTimeNode = shell_exec($cmd);
        $cmd = "cat /tmp/$filename | tail -n +2 | xmlstarlet sel -t -v '*/EndTime' ";
        $EndTime = shell_exec($cmd);
        $TimeArray = explode(".", $EndTime);
        $EndTime = $TimeArray[0];
        #echo "<br/> End Time = $EndTime";
	$cmd = "rm /tmp/$filename";
	#shell_exec($cmd);
	#echo "<br/>$site";
	echo "<br/><center>Your TestID: <b style='color:ForestGreen;'>$testid</b> ( <b style='color:#0040ff;'>$testdev</b>)</center>";
	echo "<br/><center>Data: <b style='color:#0040ff;'>$sn</b> (<b style='color:ForestGreen;'>$StartTime</b> to <b style='color:ForestGreen;'>$EndTime</b>)</center><br/><br/>";
	$tmpArray = explode("T", $StartTime);
	$dateStart = $tmpArray[0];
	$timeStart = $tmpArray[1];
	$tmpArray = explode("T", $EndTime);
	$dateEnd = $tmpArray[0];
        $timeEnd = $tmpArray[1];
	$tmpArray = explode("-", $dateStart);
	$yearStart = $tmpArray[0];
	$monthStart = $tmpArray[1];
	$dayStart = $tmpArray[2];
	$tmpArray = explode("-", $dateEnd);
	$yearEnd = $tmpArray[0];
        $monthEnd = $tmpArray[1];
        $dayEnd = $tmpArray[2];
	$tmpArray = explode(":", $timeStart);
	$hourStart = $tmpArray[0];
	$minuteStart = $tmpArray[1];
	$tmpArray = explode(":", $timeEnd);
	$hourEnd = $tmpArray[0];
	$minuteEnd = $tmpArray[1];
	$ThaiYear = "2000";
	if ( $yearStart > "2500" )
	{
		$ThaiYear=$yearStart - 543;
	} else {
		$ThaiYear=$yearStart + 543;
	}
	echo "<!--<center> Check : $yearStart $monthStart $dayStart $hourStart && $yearEnd $monthEnd $dayEnd $hourEnd</center>-->";
	$grepDate = "";
	if ("$dayStart" == "$dayEnd")
	{
		$grepDate = "grep -e '$dateStart' -e '$ThaiYear-$monthStart-$dayStart'";
		$grepHour = "grep";
		for ($i = $hourStart; $i <= $hourEnd; $i++) {
			$stri = strval($i);
                        if (strlen($stri) == 1)
                        {
                                $stri = "0$stri";
                        }
                        $grepHour = "$grepHour -e T$stri -e _$stri";
		}
		#for ($i = "00"; $i <= $minuteStart-1; $i++) {
                #        $stri = strval($i);
                #        if (strlen($stri) == 1)
                #        {
                #                $stri = "0$stri";
                #        }
                #        $grepHour = "$grepHour -v T$hourStart$stri";
                #}
		#for ($i = $minuteEnd + 1; $i <= "60"; $i++) {
		#	$stri = strval($i);
                #        if (strlen($stri) == 1)
                #        {
                #                $stri = "0$stri";
                #        }
		#	$grepHour = "$grepHour -v T$hourEnd$stri";
		#}
	} else {
		$grepDate = "grep -e '$dateStart' -e '$ThaiYear-$monthStart-$dayStart' -e '$dateEnd' -e '$ThaiYear-$monthEnd-$dayEnd'";
		$grepHour = "grep";
	#	for ($i = "00"; $i <= $minuteStart-1; $i++) {
	#		$stri = strval($i);
	#		if (strlen($stri) == 1)
	#		{
	#			$stri = "0$stri";
	#		}
	#		$grepHour = "$grepHour -v T$hourStart$stri";
        #        }
                for ($i = $hourStart; $i <= 23; $i++) {
			$stri = strval($i);
                        if (strlen($stri) == 1)
                        {
                                $stri = "0$stri";
                        }
			$grepHour = "$grepHour -e T$stri -e _$stri";
                }
		for ($i = "00"; $i <= $hourEnd; $i++) {
			$stri = strval($i);
                        if (strlen($stri) == 1)
                        {
                                $stri = "0$stri";
                        }
                        $grepHour = "$grepHour -e T$stri -e _$stri";
                }
	#	for ($i = $minuteEnd + 1; $i <= "60"; $i++) {
	#		$stri = strval($i);
        #                if (strlen($stri) == 1)
        #                {
        #                        $stri = "0$stri";
        #                }
        #                $grepHour = "$grepHour -v T$hourEnd$stri";
        #        }
	}
	$grepMinute = "";
        for ($i = "00"; $i <= $minuteStart-1; $i++) {
                 $stri = strval($i);
                 if (strlen($stri) == 1)
                {
                    $stri = "0$stri";
                }
                $grepMinute = "$grepMinute | grep -v T$hourStart$stri| grep -v ${hourStart}_$stri";
        }
        for ($i = $minuteEnd + 1; $i <= "59"; $i++) {
                $stri = strval($i);
                if (strlen($stri) == 1)
                {
                    $stri = "0$stri";
                }
                $grepMinute = "$grepMinute | grep -v T$hourEnd$stri | grep -v ${hourEnd}_$stri";
	}
	$grepCmd="grep $sn|$grepDate|$grepHour$grepMinute";
	if ("$ScriptName" != "index.php")
        {
		echo "<br/>$grepCmd<br/>";
	}
echo "<br/><a href = 'http://10.62.1.201/home/DCA/$ScriptName'>Go back</a>";
echo "<div class='hover_img'>";
$cmd = "unzip -p /home/DCA/database.zip database.txt | $grepCmd ";
$output = shell_exec($cmd);
foreach(preg_split("/((\r?\n)|(\r\n?))/", $output) as $line){
        $path_parts = pathinfo($line);
        $dir_name=$path_parts['dirname'];
        $file=$path_parts['basename'];
        $path_info_2 =pathinfo($dir_name);
        $date=$path_info_2['basename'];
        echo "<pre><a href='http://10.62.1.201/home/DCA/$date/$file' target='_blank'>$file<span><img src='http://10.62.1.201/home/DCA/$date/$file' alt='image' height='300' /></span></a></pre>";
}

$cmd = "unzip -p /home/DCA/database2.zip database2.txt | $grepCmd ";
$output = shell_exec($cmd);
foreach(preg_split("/((\r?\n)|(\r\n?))/", $output) as $line){
        $path_parts = pathinfo($line);
        $dir_name=$path_parts['dirname'];
        $file=$path_parts['basename'];
        $path_info_2 =pathinfo($dir_name);
        $date=$path_info_2['basename'];
        echo "<pre><a href='http://10.62.1.201/JDSU/DCA/$date/$file' target='_blank'>$file<span><img src='http://10.62.1.201/JDSU/DCA/$date/$file' alt='image' height='300' /></span></a></pre>";
}

$cmd = "unzip -p /home/DCAK9/databaseK9.zip databaseK9.txt | $grepCmd ";
$output = shell_exec($cmd);
foreach(preg_split("/((\r?\n)|(\r\n?))/", $output) as $line){
        $path_parts = pathinfo($line);
        $dir_name=$path_parts['dirname'];
        $file=$path_parts['basename'];
        $path_info_2 =pathinfo($dir_name);
        $date=$path_info_2['basename'];
        echo "<pre><a href='http://10.62.1.201/home/DCAK9/$date/$file' target='_blank'>$file<span><img src='http://10.62.1.201/home/DCAK9/$date/$file' alt='image' height='300' /></span></a></pre>";
}
echo "</div>";
echo "<br/><a href = 'http://10.62.1.201/home/DCA/$ScriptName'>Go back</a>";
} elseif (isset($_POST['submit'])) {
$test = $_POST['Hex'];
$test = trim($test);
#$cmd = "find /home/DCA/ | grep '$test'";
#$cmd = "find . -printf '%T@ %Tc %p\\n' | sort -n | grep '$test' | awk {'print $9'}";
#$cmd = "find . -newermt \"\$newerthan\" ! -newermt \"\$olderthan\" -printf \"%T+\\t%p\\n\" | sort | awk '{print $2}' | grep '$test'";
#$cmd = "find /home/DCA/ -type f -print0 | xargs -0 stat -c \"%y %n\" | sort | grep '$test' | awk '{print $4}'";
#$test2 = str_replace("  "," ",$test);
#$test3 = str_replace("  "," ",$test2);
$test3 = preg_replace('!\s+!', ' ', $test);
$test = $test3;
$test2 = str_replace(" ","|grep -i ",$test);
echo "<br/><center>Your Keyword: <b style='color:ForestGreen;'>$test</b></center><br/><br/>";
$test = $test2;
echo "<br/><a href = 'http://10.62.1.201/home/DCA/$ScriptName'>Go back</a>";
echo "<div class='hover_img'>";
$cmd = "unzip -p /home/DCA/database.zip database.txt | grep -i $test ";
#$cmd = "locate -d /home/DCA/mDatabase.db -i $test ";
$output = shell_exec($cmd);

foreach(preg_split("/((\r?\n)|(\r\n?))/", $output) as $line){
	$path_parts = pathinfo($line);
	$dir_name=$path_parts['dirname'];
	$file=$path_parts['basename'];
	$path_info_2 =pathinfo($dir_name);
	$date=$path_info_2['basename'];
	echo "<pre><a href='http://10.62.1.201/home/DCA/$date/$file' target='_blank'>$file<span><img src='http://10.62.1.201/home/DCA/$date/$file' alt='image' height='300' /></span></a></pre>";
} 

$cmd = "unzip -p /home/DCA/database2.zip database2.txt | grep $test ";
$output = shell_exec($cmd);
foreach(preg_split("/((\r?\n)|(\r\n?))/", $output) as $line){
        $path_parts = pathinfo($line);
        $dir_name=$path_parts['dirname'];
        $file=$path_parts['basename'];
        $path_info_2 =pathinfo($dir_name);
        $date=$path_info_2['basename'];
        echo "<pre><a href='http://10.62.1.201/JDSU/DCA/$date/$file' target='_blank'>$file<span><img src='http://10.62.1.201/JDSU/DCA/$date/$file' alt='image' height='300' /></span></a></pre>";
}

$cmd = "unzip -p /home/DCAK9/databaseK9.zip databaseK9.txt | grep $test ";
$output = shell_exec($cmd);
foreach(preg_split("/((\r?\n)|(\r\n?))/", $output) as $line){
        $path_parts = pathinfo($line);
        $dir_name=$path_parts['dirname'];
        $file=$path_parts['basename'];
        $path_info_2 =pathinfo($dir_name);
        $date=$path_info_2['basename'];
        echo "<pre><a href='http://10.62.1.201/home/DCAK9/$date/$file' target='_blank'>$file<span><img src='http://10.62.1.201/home/DCAK9/$date/$file' alt='image' height='300' /></span></a></pre>";
}
echo "</div>";
echo "<br/><a href = 'http://10.62.1.201/home/DCA/$ScriptName'>Go back</a>";

} else { ?>
<form method="post" action="">
<!--<div style="text-align:center;">-->
<div class="relative2">
<br/>
Search by Keyword : <br/><br/> Input <i><b style="color:White;">SN</b></i> you want to search <br>eg: <i style="color:White;">"CE2868770074"</i> <br> or <br> <i style="color:White;"><b>FILENAME</b></i> you want to search <br>
eg <i style="color:White;">"DcaImageSerialNumberFJ23261101BDTxChannel001Temperature+35.0Volts+3.30_+1.80_+5.00Sequence001DateTime2018-07-10T1351.433882598+0700TestID"</i>:<br/>
eg <i style="color:White;">"Port00_DcaImageSerialNumberNJ1192740037TxChannelxxxTemperature+73.0Volts+3.30_+x.xx_+x.xxSequence001DateTime2018-11-14T0716.114662001+0700TestID"</i>:<br/>
 <br> or <br> Any keyword in filename example datetime <i style="color:White;">2018-11-22</i><br/>
<br/><input type="text" name="Hex" /><br/>
<input type="submit" value="Search" name="submit" />  
<br/>
<br/>
Keyword is
<b style="color:White;">CASE IN-SENSITIVE</B> and use space for multiple keywords
</div>
</form>
<br/>
<br/>
<form method="post" action="">
<div class="relative1">
Search by TestID : <br/><br/>
input the specific TestID, choose the specific TDS data and click "Search by TestID"<br/><br/>
<input type="text" name="TestID" maxlength="10" style="width:30%"/>
<select name="SITE" style="width:20%">
  <option value="http://pgoracledb1/pls/webstart/pltestdata.gettd?tid=">CTH(testdev3 - pgoracledb1)</option>
  <option value="http://fnoracledb1/pls/webstart/pltestdata.gettd?tid=">FBN Tunable(testdev4 - fnoracledb1)</option>
  <option value="http://fnoracledb2/pls/webstart/pltestdata.gettd?tid=">FBN Plugable(testdev5 - fnoracledb2)</option>
  <option value="http://patapptdsprd01/transceiver/pltestdata.gettd?tid=">Nava(Transceiver - patapptdsprd01)</option>
</select><br/>
<input type="submit" value="Search by TestID" name="submittestid" style="width:51%" />
</div>
</form>
<?php } ?>
</BODY>
</HTML>
